function NHANVIEN(_taiKhoan
    , _hoVaTen
    , _email
    , _pass
    , _ngayLam
    , _luongCoBan
    , _chucVuCoBan
    ,_chucVuIndex
    , _gioLam) {
    this.taiKhoan = _taiKhoan;
    this.hoVaTen = _hoVaTen;
    this.email = _email;
    this.pass = _pass;
    this.ngayLam = _ngayLam;
    this.luongCoBan = _luongCoBan; 
    this.chucVuCoBan = _chucVuCoBan;
    this.chucVuIndex=_chucVuIndex;
    this.gioLam = _gioLam;
    this.tongLuong = 0;
    this.xepLoai = "";
    //
    this.tinhTongLuong = function () {
        if (this.chucVuIndex) {
            switch (this.chucVuIndex*1) {
                case 1:
                    this.tongLuong = parseFloat(this.luongCoBan) * 3;
                    break;
                case 2:
                    this.tongLuong = parseFloat(this.luongCoBan) * 2;
                    break;
                case 3:
                    this.tongLuong = parseFloat(this.luongCoBan);
                    break;
            }
            return this.tongLuong;
        }

    }
    this.tinhXepLoai = function() {
        if (this.gioLam > 0 && this.gioLam < 160) {
            return this.xepLoai = "Nhân viên trung bình"
        }
        else if (this.gioLam < 176 && this.gioLam >= 160) {
            return this.xepLoai = "Nhân viên khá"
        }
        else if (this.gioLam < 192 && this.gioLam >= 176) {
            return this.xepLoai = "Nhân viên giỏi"
        }
        else if (this.gioLam >= 192) {
            return this.xepLoai = "Nhân viên xuất sắc"
        }
    }
}