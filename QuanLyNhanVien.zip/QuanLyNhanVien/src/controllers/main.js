
var qlnv = new QLNV();
getData();

function getid(id) {
    return document.getElementById(id)
}

function nhanThongTin() {
    var taiKhoanNV = getid("tknv").value;
    var TenNV = getid("name").value;
    var emailNV = getid("email").value;
    var passNV = getid("password").value;
    var ngayLam = getid("datepicker").value;
    var luongCB_NV = getid("luongCB").value;

    var chucVu = getid("chucvu").value;
    var chucVuIndex = getid("chucvu").selectedIndex;

    var gioLamNV = getid("gioLam").value * 1;

    var ktkt = true;
    var kiemTraLoi = new KiemTraLoi();
    var txtSO = /^[0-9]+$/;
    var txtVienNamese = "^[a-zA-Z_ÀÁÂÃÈÉÊẾÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶ" + "ẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợ" + "ụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ\\s]+$";
    var txtEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var txtPass = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{0,}$/;
    ktkt &= kiemTraLoi.kiemTra(taiKhoanNV, 4, 6, "errorTK", txtSO, '(*)vui lòng nhập số tài khoản', "(*)vui lòng nhập số có 4 chữ số đến 6", '(*)chỉ nhập số')
    ktkt &= kiemTraLoi.kiemTra(TenNV, 0, 100000, "errorTen", txtVienNamese, '(*)vui lòng nhập tên', "", '(*)chỉ nhập chữ')
    ktkt &= kiemTraLoi.kiemTra(emailNV, 0, 100000, "errorEmail", txtEmail, '(*)vui lòng nhập gmail', "", '(*)Vui lòng nhập đúng định dạng')
    ktkt &= kiemTraLoi.kiemTra(emailNV, 6, 10, "errorMK", txtPass, '(*)vui lòng nhập mật khẩu', "", '(*)chứa ít nhất 1 ký tự số, 1 ký tự in hoa, 1 ký tự đặc biệt')
    console.log(ktkt);
    if (!ktkt) return;


    var nhanVien = new NHANVIEN(taiKhoanNV, TenNV, emailNV, passNV, ngayLam, luongCB_NV, chucVu, chucVuIndex, gioLamNV);
    nhanVien.tinhTongLuong();
    nhanVien.tinhXepLoai();

    return nhanVien;
}
function resetnv() {
    getid("tknv").value = "";
    getid("name").value = "";
    getid("email").value = "";
    getid("password").value = "";
    getid("datepicker").value = "";
    getid("luongCB").value = "";
    getid("chucvu").selectedIndex = 0;
    getid("gioLam").value = "";

}
getid("btnDong").onclick = function () {
    resetnv;
}
getid("btnThem").onclick = function () {
    getid("btnCapNhat").style.display = "none";
    resetnv();
    getid("btnThemNV").style.display = "block";
}

getid("btnThemNV").onclick = function () {
    var nv = nhanThongTin();
    if (nv) {
        qlnv.themNV(nv);

        renderTable(qlnv.arr);
        setData();
        getid("btnDong").click();
    }

};

function renderTable(data) {
    var inforNV = "";
    for (let i = 0; i < data.length; i++) {
        var nv = data[i];
        inforNV += `
        <tr>
        <td>${nv.taiKhoan}</td>
        <td>${nv.hoVaTen}</td>
        <td>${nv.email}</td>
        <td>${nv.ngayLam}</td>
        <td>${nv.chucVuCoBan}</td>
        <td>${nv.tongLuong}</td>
        <td>${nv.xepLoai}</td>
        <td>
        <button class="btn btn-warning" onclick="editData('${nv.taiKhoan}')">sửa</button>
        <button class="btn btn-danger" onclick="delNV('${nv.taiKhoan}')">xóa</button>
        </td>
        </tr>
        `
    };
    return getid("tableDanhSach").innerHTML = inforNV;

}
function delNV(numberNV) {
    qlnv.xoaNguoiDung(numberNV)
    renderTable(qlnv.arr);
    setData();
}

function editData(numberNV) {
    var nv = qlnv.suaNguoiDung(numberNV);
    if (nv) {
        getid("btnThem").click();

        getid("tknv").value = nv.taiKhoan;
        getid("name").value = nv.hoVaTen;
        getid("email").value = nv.email;
        getid("password").value = nv.pass;
        getid("datepicker").value = nv.ngayLam;
        getid("luongCB").value = nv.luongCoBan;
        getid("chucvu").value = nv.chucVuCoBan;
        getid("gioLam").value = nv.gioLam;

        getid("btnCapNhat").style.display = "block";
        getid("btnThemNV").style.display = "none";

        getid("btnCapNhat").onclick = function () {
            updateNV();
        }
    }
    return;
}
function updateNV() {
    var nvUpdate = nhanThongTin();
    qlnv.capnhat(nvUpdate);
    renderTable(qlnv.arr);
    getid("btnDong").click();

    return;
}


function setData() {
    var string = JSON.stringify(qlnv.arr);
    localStorage.setItem("DSNV", string);
}
getData();
function getData() {
    if (localStorage.getItem("DSNV")) {
        var conver = localStorage.getItem("DSNV");
        qlnv.arr = JSON.parse(conver);
        renderTable(qlnv.arr);
    }
}


