function QLNV() {
    this.arr = [];
    this.themNV = function (nv) {
        this.arr.push(nv)
    };
    this.timNV = function (numberNV) {
        var index = -1;
        for (var i = 0; i < this.arr.length; i++) {
            var nvii = this.arr[i];
            if (nvii.taiKhoan === numberNV) {
                index = i;
                break;
            }
        }
        console.log(index);
        return index;
    }
    this.suaNguoiDung = function (numberNV) {
       var index = this.timNV(numberNV);
       if (index!==-1) {
        var nv = this.arr[index];
       }
       return nv;
    }
    this.capnhat = function capnhat(nv) {
        var index= this.timNV(nv.taiKhoan);
        if (index!==-1) {
            this.arr[index]=nv;
        }
        return;
    }
    this.xoaNguoiDung = function xoaNguoiDung(numberNV) {
        var nvDel = this.timNV(numberNV);
        if (nvDel !== -1) {
            this.arr.splice(nvDel, 1);
        }
        return;
    }

}