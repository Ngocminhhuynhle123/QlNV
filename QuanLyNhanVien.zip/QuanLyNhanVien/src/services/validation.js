function KiemTraLoi() {
    this.kiemTra = function (data, min, max, idError, txterror, mesRong, mesChuoiKiTu, mesDinhDang) {
        if (data === "") {
            getid(idError).style.display = "block"
            getid(idError).innerHTML = mesRong;
            return false;
        }
        else if (min <= data.trim().length && max >= data.trim().length) {
            var letter = txterror;
            if (data.match(letter)) {
                return true;
            }
            else {
                getid(idError).style.display = "block";
                getid(idError).innerHTML = mesDinhDang;
                return false;
            }
        }
        else {
            getid(idError).style.display = "block";
            getid(idError).innerHTML = mesChuoiKiTu;
            return false;
        }
    }
}